<h1>YouTubeTall</h1>
    <p>Removes all YouTube Shorts from grid view subscription feed.</p>
    <img
      src="YouTubeTall.png"
      alt="YouTubeTall icon"
      width="128"
      height="128"
    />
    <p>Developed by <a href="https://www.kushshah.net">Kush Shah</a></p>
